<template>
    <div>
        <h1>I am comp A and the counter is : {{$store.state.conuter}}</h1>
    </div>
</template>